
export type Currency = 'USD' | 'VES' | 'USDT';

export interface PaymentMethod {
  id: string;
  name: string;
  currency: Currency;
  symbol: string;
  minSend: number;
  maxSend: number;
  minReceive: number;
  maxReceive: number;
  commission: number;
  fields: FieldType[];
}

export type FieldType = 
  | 'email' 
  | 'email_or_phone' 
  | 'phone' 
  | 'cedula' 
  | 'bank' 
  | 'account_number' 
  | 'crypto_address' 
  | 'network';

export interface ExchangeRateMap {
  [key: string]: number;
}

export interface TransactionState {
  currentStep: number;
  selectedSendId: string | null;
  selectedReceiveId: string | null;
  amount: number;
  outputAmount: number;
  rate: number;
  commission: number;
  formData: Record<string, string>;
}

export interface LogEntry {
  timestamp: string;
  message: string;
}
