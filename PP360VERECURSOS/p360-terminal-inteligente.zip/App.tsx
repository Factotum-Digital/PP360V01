
import React, { useState, useEffect } from 'react';
import { PAYMENT_METHODS, EXCHANGE_RATES } from './constants';
import { TransactionState, LogEntry } from './types';
import { getMarketIntelligence } from './geminiService';
import Sidebar from './components/Sidebar';
import TerminalLogs from './components/TerminalLogs';
import RateChart from './components/RateChart';
import { 
  ArrowRight, 
  ArrowUpDown, 
  CheckCircle, 
  AlertTriangle, 
  ShieldCheck, 
  Clock, 
  Zap,
  Check
} from 'lucide-react';

const App: React.FC = () => {
  const [state, setState] = useState<TransactionState>({
    currentStep: 1,
    selectedSendId: null,
    selectedReceiveId: null,
    amount: 100,
    outputAmount: 0,
    rate: 0,
    commission: 0,
    formData: {}
  });

  const [logs, setLogs] = useState<LogEntry[]>([
    { timestamp: new Date().toLocaleTimeString(), message: "BOOTING_P360_KERNEL... DONE" },
    { timestamp: new Date().toLocaleTimeString(), message: "CONNECTING_API_SALDOAR... OK" },
    { timestamp: new Date().toLocaleTimeString(), message: "ESTABLISHING_SECURE_TUNNEL... ENCRYPTED" }
  ]);

  const [aiInsight, setAiInsight] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [operationId, setOperationId] = useState("");

  const addLog = (message: string) => {
    setLogs(prev => [
      { timestamp: new Date().toLocaleTimeString(), message },
      ...prev.slice(0, 49)
    ]);
  };

  const handleMethodSelect = (type: 'send' | 'receive', methodId: string) => {
    setState(prev => {
      const nextState = { ...prev };
      if (type === 'send') {
        nextState.selectedSendId = methodId;
      } else {
        nextState.selectedReceiveId = methodId;
      }
      return nextState;
    });
    
    const methodName = PAYMENT_METHODS[methodId]?.name;
    addLog(`SET_${type.toUpperCase()}_CHANNEL: ${methodName}`);
  };

  useEffect(() => {
    if (state.selectedSendId && state.selectedReceiveId) {
      const rateKey = `${state.selectedSendId}_${state.selectedReceiveId}`;
      const rate = EXCHANGE_RATES[rateKey] || (state.selectedSendId === state.selectedReceiveId ? 1 : 0);
      const receiveMethod = PAYMENT_METHODS[state.selectedReceiveId];
      
      const commission = receiveMethod.commission;
      const netAmount = state.amount * (1 - commission);
      const output = netAmount * (rate || 0);

      setState(prev => ({ 
        ...prev, 
        rate: rate || 0, 
        commission, 
        outputAmount: output 
      }));
    }
  }, [state.selectedSendId, state.selectedReceiveId, state.amount]);

  const triggerAiInsight = async () => {
    if (state.selectedSendId && state.selectedReceiveId) {
      setAiInsight("Analizando mercado...");
      const insight = await getMarketIntelligence(
        PAYMENT_METHODS[state.selectedSendId].name,
        PAYMENT_METHODS[state.selectedReceiveId].name,
        state.amount
      );
      setAiInsight(insight || "IA: Kernel operando en modo estático.");
    }
  };

  const goToStep = (step: number) => {
    if (step === 2) {
      if (!state.selectedSendId || !state.selectedReceiveId) {
        addLog("ERROR: SELECCIÓN INCOMPLETA");
        return;
      }
      triggerAiInsight();
    }
    setState(prev => ({ ...prev, currentStep: step }));
    addLog(`NAVIGATED_TO_STEP_${step}`);
    window.scrollTo(0, 0);
  };

  const finalizeOrder = () => {
    setIsProcessing(true);
    addLog("PROCESSING_TRANSACTION...");
    addLog("ENCRYPTING_PAYMENT_DATA...");
    
    setTimeout(() => {
      const id = `P360-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
      setOperationId(id);
      setState(prev => ({ ...prev, currentStep: 4 }));
      setIsProcessing(false);
      addLog(`ORDER_COMMITTED: ${id}`);
    }, 2500);
  };

  const selectedSend = state.selectedSendId ? PAYMENT_METHODS[state.selectedSendId] : null;
  const selectedReceive = state.selectedReceiveId ? PAYMENT_METHODS[state.selectedReceiveId] : null;

  return (
    <div className="flex min-h-screen">
      <Sidebar />

      <main className="flex-1 p-6 md:p-12 lg:p-20">
        <div className="max-w-6xl mx-auto">
          
          <header className="mb-16">
            <div className="flex items-center gap-4 mb-4">
              <span className="mono text-[10px] bg-[#262626] text-white px-2 py-1">AUTH: OK</span>
              <span className="mono text-[10px] text-gray-400 uppercase">SERVER: NODE-79</span>
              <span className="mono text-[10px] bg-[#FF4C00] text-white px-2 py-1 font-bold">OPERACIONAL</span>
            </div>
            <h1 className="font-black uppercase tracking-tighter text-[#262626]">
              P360 <br /><span className="text-transparent" style={{ WebkitTextStroke: '2px #262626' }}>TERMINAL</span>
            </h1>
            <p className="mono text-sm mt-4 max-w-xl text-gray-500 font-bold uppercase">
              Operaciones de cambio de alta liquidez. Seguro. Instantáneo.
            </p>
          </header>

          <div className="grid lg:grid-cols-12 gap-12">
            
            <div className="lg:col-span-7 xl:col-span-8 space-y-12">
              
              <div className="slab p-6 md:p-10 relative overflow-hidden min-h-[650px] flex flex-col">
                <div className="absolute top-0 right-0 flex border-l-2 border-b-2 border-[#262626] mono text-[10px] font-black">
                  {[1, 2, 3].map(s => (
                    <div 
                      key={s} 
                      className={`px-4 py-2 border-l-2 border-[#262626] transition-colors ${state.currentStep === s ? 'bg-[#262626] text-white' : 'bg-white text-[#262626] opacity-30'}`}
                    >
                      S_0{s}
                    </div>
                  ))}
                </div>

                {state.currentStep === 1 && (
                  <div className="space-y-10 animate-reveal mt-6">
                    <h3 className="mono text-2xl font-black uppercase underline decoration-4 decoration-[#FF4C00]">Selección de Canal</h3>
                    
                    <div className="space-y-4">
                      <label className="mono text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                        <span className="w-3 h-3 bg-[#262626]"></span> TÚ ENVÍAS (ORIGEN)
                      </label>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {Object.values(PAYMENT_METHODS).map(m => (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => handleMethodSelect('send', m.id)}
                            className={`p-4 border-2 border-[#262626] transition-all mono text-left relative group ${state.selectedSendId === m.id ? 'bg-[#262626] text-white shadow-[4px_4px_0px_0px_#FF4C00]' : 'bg-white hover:bg-gray-50'}`}
                          >
                            <div className="font-black uppercase">{m.name}</div>
                            <div className={`text-[10px] ${state.selectedSendId === m.id ? 'text-gray-400' : 'text-gray-500'}`}>{m.currency}</div>
                            {state.selectedSendId === m.id && (
                              <Check className="absolute top-2 right-2 text-[#FF4C00]" size={16} strokeWidth={4} />
                            )}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="mono text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                        <span className="w-3 h-3 bg-[#FF4C00]"></span> TÚ RECIBES (DESTINO)
                      </label>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {Object.values(PAYMENT_METHODS).map(m => (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => handleMethodSelect('receive', m.id)}
                            className={`p-4 border-2 border-[#262626] transition-all mono text-left relative group ${state.selectedReceiveId === m.id ? 'bg-[#FF4C00] text-white' : 'bg-white hover:bg-gray-50'}`}
                          >
                            <div className="font-black uppercase">{m.name}</div>
                            <div className={`text-[10px] ${state.selectedReceiveId === m.id ? 'text-white opacity-60' : 'text-gray-500'}`}>{m.currency}</div>
                            {state.selectedReceiveId === m.id && (
                              <Check className="absolute top-2 right-2 text-white" size={16} strokeWidth={4} />
                            )}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button 
                      type="button"
                      disabled={!state.selectedSendId || !state.selectedReceiveId}
                      onClick={() => goToStep(2)}
                      className="w-full mt-auto bg-[#262626] text-white p-8 text-xl font-black uppercase flex justify-between items-center slab-dark btn-press disabled:opacity-20 disabled:grayscale transition-all group"
                    >
                      <span>Cotizar Operación</span>
                      <ArrowRight className="group-hover:translate-x-2 transition-transform" strokeWidth={4} />
                    </button>
                  </div>
                )}

                {state.currentStep === 2 && selectedSend && selectedReceive && (
                  <div className="space-y-10 animate-reveal mt-6">
                    <h3 className="mono text-2xl font-black uppercase underline decoration-4 decoration-[#FF4C00]">Cotización Real</h3>
                    
                    <div className="space-y-4">
                      <label className="mono text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                        TÚ ENVÍAS ({selectedSend.currency})
                      </label>
                      <div className="relative">
                        <span className="absolute left-6 top-1/2 -translate-y-1/2 font-black text-4xl opacity-10">{selectedSend.symbol}</span>
                        <input 
                          type="number"
                          value={state.amount}
                          onChange={(e) => setState(prev => ({ ...prev, amount: Number(e.target.value) }))}
                          className="w-full bg-transparent border-b-4 border-[#262626] p-8 pl-16 text-5xl font-black mono focus:bg-white transition-all outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="h-0.5 flex-1 bg-[#262626] opacity-20"></div>
                      <div className="w-12 h-12 border-2 border-[#262626] flex items-center justify-center bg-white">
                        <ArrowUpDown strokeWidth={4} className="text-[#FF4C00]" />
                      </div>
                      <div className="h-0.5 flex-1 bg-[#262626] opacity-20"></div>
                    </div>

                    <div className="space-y-4">
                      <label className="mono text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                        TÚ RECIBES ({selectedReceive.currency})
                      </label>
                      <div className="relative">
                        <span className="absolute left-6 top-1/2 -translate-y-1/2 font-black text-4xl opacity-20">{selectedReceive.symbol}</span>
                        <input 
                          readOnly
                          value={state.outputAmount.toLocaleString('es-VE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          className="w-full bg-[#262626] text-white p-8 pl-24 text-5xl font-black mono cursor-not-allowed outline-none"
                        />
                      </div>
                      <div className="flex justify-between mono text-[10px] font-black text-gray-500 uppercase">
                        <span>TASA: 1 {selectedSend.currency} = {state.rate.toFixed(4)} {selectedReceive.currency}</span>
                        <span>COMISIÓN: {(state.commission * 100).toFixed(1)}%</span>
                      </div>
                    </div>

                    <div className="bg-orange-50 p-6 border-l-8 border-[#FF4C00] flex gap-4 items-start">
                      <Zap className="text-[#FF4C00] shrink-0" size={24} strokeWidth={3} />
                      <div>
                        <div className="mono text-[10px] font-black uppercase text-[#FF4C00] mb-1">MARKET_INTELLIGENCE</div>
                        <p className="mono text-[11px] font-bold uppercase leading-tight">{aiInsight}</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <button onClick={() => goToStep(1)} className="w-1/3 border-2 border-[#262626] p-6 font-black uppercase mono hover:bg-gray-50 btn-press">Volver</button>
                      <button onClick={() => goToStep(3)} className="flex-1 bg-[#262626] text-white p-6 text-xl font-black uppercase slab-dark btn-press">Continuar</button>
                    </div>
                  </div>
                )}

                {state.currentStep === 3 && selectedSend && selectedReceive && (
                  <div className="space-y-8 animate-reveal mt-6">
                    <h3 className="mono text-2xl font-black uppercase underline decoration-4 decoration-[#FF4C00]">Datos de Liquidación</h3>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                      {[...selectedSend.fields, ...selectedReceive.fields].map((field, idx) => (
                        <div key={idx} className="space-y-2">
                          <label className="mono text-[10px] font-black uppercase">{field.replace('_', ' ')} *</label>
                          <input 
                            type="text"
                            placeholder="REQUERIDO"
                            onChange={(e) => setState(prev => ({ ...prev, formData: { ...prev.formData, [field]: e.target.value } }))}
                            className="w-full border-2 border-[#262626] p-4 font-bold mono outline-none focus:bg-gray-50"
                          />
                        </div>
                      ))}
                    </div>

                    <div className="bg-orange-50 p-4 border-l-8 border-[#FF4C00] flex gap-4">
                      <AlertTriangle className="text-[#FF4C00] shrink-0" size={24} />
                      <p className="mono text-[10px] font-bold leading-tight uppercase text-[#262626]">
                        Solo aceptamos pagos de cuentas verificadas y a nombre del titular de la cuenta de destino.
                      </p>
                    </div>

                    <div className="flex gap-4">
                      <button onClick={() => goToStep(2)} className="w-1/3 border-2 border-[#262626] p-6 font-black uppercase mono hover:bg-gray-50 btn-press">Volver</button>
                      <button 
                        onClick={finalizeOrder}
                        disabled={isProcessing}
                        className="flex-1 bg-[#FF4C00] text-white p-6 text-xl font-black uppercase btn-press relative flex justify-center items-center slab-dark"
                      >
                        {isProcessing ? 'Procesando...' : 'Generar Orden'}
                      </button>
                    </div>
                  </div>
                )}

                {state.currentStep === 4 && (
                  <div className="flex flex-col items-center justify-center py-16 text-center animate-reveal">
                    <div className="w-24 h-24 bg-[#FF4C00] border-4 border-[#262626] flex items-center justify-center mb-8 text-white">
                      <CheckCircle size={48} strokeWidth={3} />
                    </div>
                    <h3 className="text-5xl font-black uppercase mb-4 text-[#262626]">Orden Transmitida</h3>
                    <div className="mono space-y-4 max-w-md">
                      <p className="text-sm font-bold uppercase">ID Operación: <span className="bg-[#262626] text-white px-2 py-1">{operationId}</span></p>
                      <div className="bg-white p-6 border-2 border-[#262626] text-left space-y-2 shadow-[6px_6px_0px_0px_#FF4C00]">
                        <div className="flex justify-between text-xs"><span>Envías:</span> <span className="font-black">{selectedSend?.symbol}{state.amount} {selectedSend?.currency}</span></div>
                        <div className="flex justify-between text-xs text-[#FF4C00]"><span>Recibes:</span> <span className="font-black">{selectedReceive?.symbol}{state.outputAmount.toLocaleString()} {selectedReceive?.currency}</span></div>
                        <div className="flex justify-between text-xs opacity-40"><span>Método:</span> <span className="font-black uppercase">{selectedSend?.name} → {selectedReceive?.name}</span></div>
                      </div>
                    </div>
                    <button 
                      onClick={() => window.location.reload()}
                      className="mt-12 border-2 border-[#262626] px-12 py-4 font-black mono uppercase hover:bg-[#262626] hover:text-white transition-all btn-press"
                    >
                      Nueva Operación
                    </button>
                  </div>
                )}
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                <div className="slab p-6 bg-white">
                  <ShieldCheck className="mb-2 text-[#FF4C00]" size={20} strokeWidth={3} />
                  <div className="mono text-[10px] font-black mb-1 uppercase tracking-wider">Seguridad</div>
                  <p className="text-[9px] font-bold leading-tight uppercase text-gray-400">Encriptación AES-256 en cada fragmento.</p>
                </div>
                <div className="slab p-6">
                  <Clock className="mb-2 text-[#FF4C00]" size={20} strokeWidth={3} />
                  <div className="mono text-[10px] font-black mb-1 uppercase tracking-wider">Fast_Track</div>
                  <p className="text-[9px] font-bold leading-tight uppercase text-gray-400">Liquidación promedio de 15 minutos.</p>
                </div>
                <div className="slab p-6 bg-[#262626] text-white">
                  <Zap className="mb-2 text-[#FF4C00]" size={20} strokeWidth={3} />
                  <div className="mono text-[10px] font-black mb-1 uppercase tracking-wider text-[#FF4C00]">Deep_Liquidity</div>
                  <p className="text-[9px] font-bold leading-tight uppercase opacity-60">Operando con fondos inmediatos.</p>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5 xl:col-span-4 space-y-8">
              <div className="slab p-8 bg-[#262626] text-white overflow-hidden relative min-h-[250px]">
                <div className="flex justify-between items-start mb-8">
                   <h3 className="mono text-[10px] font-black tracking-widest uppercase text-white opacity-40">Mercado en Vivo</h3>
                   <span className="bg-[#FF4C00] text-white px-2 py-1 mono text-[10px] font-black">+4.2%</span>
                </div>
                <RateChart />
                <div className="mt-4 flex justify-between mono text-[10px] text-gray-500 font-black">
                  <span>08:00</span>
                  <span>12:00</span>
                  <span>16:00</span>
                  <span>AHORA</span>
                </div>
              </div>

              <div className="slab p-6 space-y-6">
                <h3 className="font-black uppercase tracking-widest text-[11px] border-b-2 border-[#262626] pb-4 flex items-center gap-2">
                  <Zap size={14} className="text-[#FF4C00]" /> Tasas Referenciales
                </h3>
                <div className="space-y-3">
                  {Object.entries(EXCHANGE_RATES).slice(0, 4).map(([key, val], idx) => {
                    const [from, to] = key.split('_');
                    return (
                      <div key={idx} className="flex justify-between items-center p-3 border-2 border-[#262626] hover:bg-gray-50 transition-colors cursor-default">
                        <span className="mono text-[11px] font-black uppercase">{from} / {to}</span>
                        <div className="flex gap-4 mono text-[11px] font-black">
                          <span className="text-[#FF4C00]">↑{val.toFixed(2)}</span>
                          <span className="text-gray-300">↓{(val - 0.2).toFixed(2)}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <TerminalLogs logs={logs} />
            </div>
          </div>

          <footer className="mt-32 pt-16 border-t-2 border-[#262626] border-dashed">
            <div className="flex flex-col md:flex-row justify-between gap-12">
              <div className="max-w-md">
                <h2 className="font-black italic text-2xl mb-6 text-[#262626]">P360_NETWORK</h2>
                <p className="mono text-[10px] font-bold text-gray-400 uppercase leading-relaxed">
                  Terminal de alto rendimiento para el ecosistema financiero venezolano. Built on React 19 & Gemini API.
                </p>
              </div>
              <div className="flex flex-wrap gap-12">
                <div className="space-y-4">
                  <span className="mono text-[10px] font-black bg-[#262626] text-white px-2 py-1 uppercase">Soporte</span>
                  <ul className="mono text-[10px] font-bold uppercase space-y-2 text-gray-500">
                    <li>Telegram: @P360_Kernel</li>
                    <li>Email: support@p360.network</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <span className="mono text-[10px] font-black bg-[#FF4C00] text-white px-2 py-1 uppercase">Legal</span>
                  <ul className="mono text-[10px] font-bold uppercase space-y-2 text-gray-500">
                    <li><a href="#" className="hover:text-[#FF4C00] transition-colors">Términos</a></li>
                    <li><a href="#" className="hover:text-[#FF4C00] transition-colors">Privacidad</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </footer>
        </div>
      </main>
    </div>
  );
};

export default App;
