
import React, { useRef, useEffect } from 'react';
import { LogEntry } from '../types';

interface Props {
  logs: LogEntry[];
}

const TerminalLogs: React.FC<Props> = ({ logs }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [logs]);

  return (
    <div className="slab p-6 bg-[#262626] text-[#FF4C00] mono text-[9px] h-48 overflow-hidden relative shadow-[6px_6px_0px_0px_rgba(38,38,38,0.2)]">
      <div className="absolute top-0 left-0 w-full h-full p-4 overflow-y-auto space-y-1 flex flex-col-reverse" ref={scrollRef}>
        {logs.map((log, i) => (
          <div key={i} className="animate-reveal" style={{ animationDuration: '0.2s' }}>
            <span className="text-white opacity-30">[{log.timestamp}]</span> > {log.message}
          </div>
        ))}
      </div>
    </div>
  );
};

export default TerminalLogs;
