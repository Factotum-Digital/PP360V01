
export enum TransactionStep {
  QUOTATION = 'QUOTATION',
  DETAILS = 'DETAILS',
  SUCCESS = 'SUCCESS'
}

export interface ExchangeRate {
  rate: number;
  commission: number;
}

export interface MarketInsight {
  headline: string;
  sentiment: 'positive' | 'neutral' | 'negative';
  prediction: string;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  message: string;
}
