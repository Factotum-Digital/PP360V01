
import React, { useEffect, useRef } from 'react';
import { LogEntry } from '../types';

interface TerminalLogsProps {
  logs: LogEntry[];
}

const TerminalLogs: React.FC<TerminalLogsProps> = ({ logs }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="slab p-6 bg-gray-900 text-green-400 mono text-[9px] h-48 overflow-hidden relative">
      <div ref={scrollRef} className="absolute top-0 left-0 w-full h-full p-4 overflow-y-auto space-y-1">
        {logs.map((log) => (
          <div key={log.id} className="animate-in fade-in slide-in-from-bottom-1">
            &gt; {log.timestamp} : {log.message}
          </div>
        ))}
      </div>
    </div>
  );
};

export default TerminalLogs;
