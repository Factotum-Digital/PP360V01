
import React from 'react';
import { AreaChart, Area, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts';

const data = [
  { time: '08:00', rate: 51.2 },
  { time: '10:00', rate: 51.8 },
  { time: '12:00', rate: 52.5 },
  { time: '14:00', rate: 52.1 },
  { time: '16:00', rate: 52.85 },
  { time: '18:00', rate: 53.1 },
];

const MarketChart: React.FC = () => {
  return (
    <div className="slab p-8 bg-black text-white overflow-hidden relative">
      <div className="flex justify-between items-start mb-8">
        <h3 className="mono text-sm font-bold tracking-tighter">HISTÓRICO_TASA_VES</h3>
        <span className="bg-[#00ff66] text-black px-2 py-1 mono text-[10px] font-black">+2.4% VOL</span>
      </div>
      
      <div className="h-40 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="100%">
                <stop offset="5%" stopColor="#00ff66" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#00ff66" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis dataKey="time" hide />
            <YAxis hide domain={['dataMin - 1', 'dataMax + 1']} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#000', border: '1px solid #00ff66', color: '#00ff66' }}
              itemStyle={{ color: '#00ff66' }}
              labelStyle={{ color: '#aaa' }}
            />
            <Area 
              type="monotone" 
              dataKey="rate" 
              stroke="#00ff66" 
              fillOpacity={1} 
              fill="url(#colorRate)" 
              strokeWidth={4}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      
      <div className="mt-4 flex justify-between mono text-[10px] text-gray-500 uppercase">
        <span>08:00</span>
        <span>12:00</span>
        <span>16:00</span>
        <span>Actual</span>
      </div>
    </div>
  );
};

export default MarketChart;
