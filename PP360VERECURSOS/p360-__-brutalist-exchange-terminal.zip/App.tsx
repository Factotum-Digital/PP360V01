
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import Sidebar from './components/Sidebar';
import TerminalLogs from './components/TerminalLogs';
import MarketChart from './components/MarketChart';
import { TransactionStep, LogEntry, MarketInsight } from './types';
import { INITIAL_RATE, COMMISSION_PERCENTAGE, MIN_USD, ArrowIcon, NextIcon, CheckIcon } from './constants';
import { getMarketInsight } from './services/geminiService';

const App: React.FC = () => {
  const [step, setStep] = useState<TransactionStep>(TransactionStep.QUOTATION);
  const [usdAmount, setUsdAmount] = useState<number>(100);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [insight, setInsight] = useState<MarketInsight | null>(null);
  const [sessionId] = useState(() => Math.random().toString(36).substring(2, 10).toUpperCase());
  const [isProcessing, setIsProcessing] = useState(false);

  // Derived calculations
  const netUsd = useMemo(() => usdAmount * (1 - COMMISSION_PERCENTAGE), [usdAmount]);
  const totalVes = useMemo(() => netUsd * INITIAL_RATE, [netUsd]);

  const addLog = useCallback((message: string) => {
    const newLog: LogEntry = {
      id: Math.random().toString(36).substring(2),
      timestamp: new Date().toLocaleTimeString(),
      message: message.toUpperCase()
    };
    setLogs(prev => [...prev.slice(-49), newLog]);
  }, []);

  useEffect(() => {
    addLog("BOOTING_P360_KERNEL... DONE");
    addLog("CONNECTING_CENTRAL_BANK_API... OK");
    addLog("ESTABLISHING_SECURE_TUNNEL... ENCRYPTED");

    // Fetch initial AI insight
    getMarketInsight(INITIAL_RATE).then(setInsight);

    const interval = setInterval(() => {
      const messages = [
        "NETWORK_LATENCY: 12ms",
        "HEARTBEAT_SIGNAL: OK",
        "LIQUIDITY_POOL: REFRESHED",
        "PEER_NODE_CONNECTED: 192.168.1.44",
        "RATE_WATCHDOG: NO_DRIFT_DETECTED"
      ];
      addLog(messages[Math.floor(Math.random() * messages.length)]);
    }, 8000);

    return () => clearInterval(interval);
  }, [addLog]);

  const handleContinue = () => {
    if (usdAmount < MIN_USD) return;
    addLog(`USER_NAVIGATED: STEP_DETAILS (VALIDATION)`);
    setStep(TransactionStep.DETAILS);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBack = () => {
    addLog(`USER_NAVIGATED: STEP_QUOTATION`);
    setStep(TransactionStep.QUOTATION);
  };

  const handleFinalize = () => {
    setIsProcessing(true);
    addLog("PROCESSING_TRANSACTION...");
    addLog("ENCRYPTING_PAYMENT_DATA...");
    
    setTimeout(() => {
      setIsProcessing(false);
      setStep(TransactionStep.SUCCESS);
      addLog("ORDER_COMMITTED_SUCCESSFULLY");
    }, 2000);
  };

  return (
    <div className="flex min-h-screen">
      <Sidebar />

      <main className="flex-1 p-6 md:p-12 lg:p-20">
        <div className="max-w-6xl mx-auto">
          
          {/* HEADER SECTOR */}
          <header className="mb-16 animate-in fade-in slide-in-from-top-4 duration-700">
            <div className="flex items-end gap-4 mb-4">
              <span className="mono text-[10px] bg-black text-white px-2 py-1">AUTH: OK</span>
              <span className="mono text-[10px] text-gray-400 uppercase tracking-widest">SESSION_ID: {sessionId}</span>
            </div>
            <h1 className="text-6xl md:text-8xl font-black uppercase tracking-tighter leading-[0.9]">
              Cambio<br/>
              <span className="text-transparent" style={{ WebkitTextStroke: '2px black' }}>Inteligente</span>
            </h1>
          </header>

          <div className="grid lg:grid-cols-12 gap-12">
            
            {/* LEFT: THE TRANSACTION MONOLITH */}
            <div className="lg:col-span-7 xl:col-span-8 space-y-12 animate-in fade-in slide-in-from-left-4 duration-700 delay-200">
              
              <div className="slab p-6 md:p-10 relative overflow-hidden min-h-[500px]">
                {/* Step Counter Tabs */}
                <div className="absolute top-0 right-0 flex border-l-4 border-b-4 border-black">
                  <div className={`px-4 py-2 mono text-sm font-bold transition-all ${step === TransactionStep.QUOTATION ? 'bg-black text-white' : 'bg-white text-black opacity-30'}`}>STEP_01</div>
                  <div className={`px-4 py-2 mono text-sm font-bold transition-all ${step === TransactionStep.DETAILS ? 'bg-black text-white' : 'bg-white text-black opacity-30'}`}>STEP_02</div>
                </div>

                {/* STEP 1: CALCULATOR */}
                {step === TransactionStep.QUOTATION && (
                  <div className="mt-4 space-y-12 animate-in fade-in duration-300">
                    <div className="space-y-4">
                      <label className="mono text-[10px] font-bold uppercase tracking-widest flex items-center gap-2">
                        <span className="w-3 h-3 bg-black"></span> Tú envías (PayPal USD)
                      </label>
                      <div className="relative group">
                        <span className="absolute left-6 top-1/2 -translate-y-1/2 font-black text-4xl opacity-20">$</span>
                        <input 
                          type="number" 
                          value={usdAmount}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            setUsdAmount(val || 0);
                          }}
                          className="w-full bg-gray-100 border-b-8 border-black p-8 pl-16 text-5xl font-black mono focus:bg-white transition-all outline-none" 
                        />
                      </div>
                      {usdAmount < MIN_USD && (
                        <p className="text-red-600 mono text-[10px] font-bold uppercase">Monto mínimo: ${MIN_USD}.00 USD</p>
                      )}
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="h-[4px] flex-1 bg-black"></div>
                      <div className="w-16 h-16 border-4 border-black flex items-center justify-center rotate-45 bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                        <ArrowIcon className="-rotate-45" />
                      </div>
                      <div className="h-[4px] flex-1 bg-black"></div>
                    </div>

                    <div className="space-y-4">
                      <label className="mono text-[10px] font-bold uppercase tracking-widest flex items-center gap-2">
                        <span className="w-3 h-3 bg-black"></span> Tú recibes (VES)
                      </label>
                      <div className="relative">
                        <span className="absolute left-6 top-1/2 -translate-y-1/2 font-black text-4xl opacity-20">Bs</span>
                        <input 
                          type="text" 
                          value={usdAmount >= MIN_USD ? totalVes.toLocaleString('es-VE', { minimumFractionDigits: 2 }) : 'ERROR'} 
                          readOnly 
                          className="w-full bg-black text-white p-8 pl-24 text-5xl font-black mono cursor-not-allowed" 
                        />
                      </div>
                      <div className="flex justify-between items-center py-2 mono text-[10px] font-bold text-gray-500">
                        <span>RATE: 1 USD = {INITIAL_RATE.toFixed(2)} VES</span>
                        <span>COMMISSION: {(COMMISSION_PERCENTAGE * 100).toFixed(2)}% INCL.</span>
                      </div>
                    </div>

                    <button 
                      onClick={handleContinue}
                      disabled={usdAmount < MIN_USD}
                      className="group w-full bg-black text-white p-8 text-xl font-black uppercase tracking-[0.2em] flex justify-between items-center hover:bg-[#00ff66] hover:text-black transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <span>Continuar Proceso</span>
                      <NextIcon className="group-hover:translate-x-2 transition-transform" />
                    </button>
                  </div>
                )}

                {/* STEP 2: DETAILS */}
                {step === TransactionStep.DETAILS && (
                  <div className="mt-4 space-y-8 animate-in fade-in duration-300">
                    <h3 className="mono text-2xl font-black uppercase mb-4 underline decoration-4">Datos de Destino</h3>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="mono text-[10px] font-black uppercase">Email PayPal Emisor</label>
                        <input type="email" placeholder="usuario@email.com" className="w-full border-4 border-black p-4 font-bold mono focus:ring-4 ring-black/10 outline-none" />
                      </div>
                      <div className="space-y-2">
                        <label className="mono text-[10px] font-black uppercase">Banco de Destino</label>
                        <select className="w-full border-4 border-black p-4 font-bold mono appearance-none bg-white">
                          <option>Banesco</option>
                          <option>Mercantil</option>
                          <option>Banco de Venezuela</option>
                          <option>Provincial</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="mono text-[10px] font-black uppercase">Cédula / RIF</label>
                        <input type="text" placeholder="V-12345678" className="w-full border-4 border-black p-4 font-bold mono focus:ring-4 ring-black/10 outline-none" />
                      </div>
                      <div className="space-y-2">
                        <label className="mono text-[10px] font-black uppercase">Teléfono Pago Móvil</label>
                        <input type="text" placeholder="04121234567" className="w-full border-4 border-black p-4 font-bold mono focus:ring-4 ring-black/10 outline-none" />
                      </div>
                    </div>

                    <div className="bg-yellow-100 p-4 border-l-8 border-black">
                      <p className="mono text-[10px] font-bold leading-tight uppercase">ADVERTENCIA: Solo aceptamos pagos de cuentas PayPal verificadas y a nombre del titular de la cuenta bancaria. No se admiten transferencias de terceros.</p>
                    </div>

                    <div className="flex gap-4">
                      <button 
                        onClick={handleBack}
                        className="w-1/3 border-4 border-black p-6 font-black uppercase mono hover:bg-gray-100 transition-colors"
                      >
                        Volver
                      </button>
                      <button 
                        onClick={handleFinalize}
                        disabled={isProcessing}
                        className="flex-1 bg-black text-white p-6 text-xl font-black uppercase tracking-[0.2em] hover:bg-[#00ff66] hover:text-black transition-colors disabled:opacity-50"
                      >
                        {isProcessing ? 'Procesando...' : 'Finalizar Orden'}
                      </button>
                    </div>
                  </div>
                )}

                {/* SUCCESS STATE */}
                {step === TransactionStep.SUCCESS && (
                  <div className="mt-4 space-y-8 animate-in zoom-in duration-500 flex flex-col items-center justify-center py-20 text-center">
                    <div className="w-24 h-24 bg-[#00ff66] border-4 border-black flex items-center justify-center mb-6 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
                      <CheckIcon />
                    </div>
                    <h3 className="text-4xl font-black uppercase">Orden Generada</h3>
                    <p className="mono text-sm font-bold max-w-md">Hemos enviado las instrucciones de pago a su correo electrónico. Su número de ticket es <span className="bg-black text-white px-2">#P360-{Math.random().toString(36).substring(7).toUpperCase()}</span></p>
                    <button 
                      onClick={() => window.location.reload()} 
                      className="mt-8 underline font-black mono uppercase hover:text-[#00ff66] transition-colors"
                    >
                      Iniciar nueva operación
                    </button>
                  </div>
                )}
              </div>

              {/* Info Strip */}
              <div className="grid md:grid-cols-3 gap-6">
                <div className="slab p-6 bg-yellow-300">
                  <div className="mono text-xs font-black mb-2 uppercase">Seguridad_SSL</div>
                  <p className="text-[10px] font-bold leading-tight uppercase">Encriptación de grado militar en cada transacción de datos.</p>
                </div>
                <div className="slab p-6 bg-white">
                  <div className="mono text-xs font-black mb-2 uppercase">Tiempo_Promedio</div>
                  <p className="text-[10px] font-bold leading-tight uppercase">15 Minutos estimados para la liquidación total en su cuenta.</p>
                </div>
                <div className="slab p-6 bg-black text-white">
                  <div className="mono text-xs font-black mb-2 text-[#00ff66] uppercase">Status_Red</div>
                  <p className="text-[10px] font-bold leading-tight uppercase">Operando con liquidez inmediata. Todos los nodos activos.</p>
                </div>
              </div>
            </div>

            {/* RIGHT: DATA & CHARTS */}
            <div className="lg:col-span-5 xl:col-span-4 space-y-8 animate-in fade-in slide-in-from-right-4 duration-700 delay-300">
              
              <MarketChart />

              {/* Gemini AI Insight */}
              <div className="slab p-6 bg-[#00ff66]/10 border-[#00ff66]">
                 <div className="flex items-center gap-2 mb-4">
                   <div className="w-2 h-2 bg-black animate-pulse"></div>
                   <h3 className="mono text-xs font-black uppercase tracking-widest">AI_MARKET_INTELLIGENCE</h3>
                 </div>
                 {insight ? (
                   <div className="space-y-2">
                     <h4 className="font-black text-sm uppercase">{insight.headline}</h4>
                     <p className="mono text-[10px] leading-tight font-bold text-gray-600 uppercase">
                       {insight.prediction}
                     </p>
                     <div className={`text-[9px] font-black inline-block px-2 py-1 rounded-sm uppercase ${
                       insight.sentiment === 'positive' ? 'bg-[#00ff66] text-black' : 
                       insight.sentiment === 'negative' ? 'bg-red-500 text-white' : 'bg-gray-200 text-black'
                     }`}>
                       Sentiment: {insight.sentiment}
                     </div>
                   </div>
                 ) : (
                   <div className="mono text-[10px] animate-pulse">Analizando flujos de mercado...</div>
                 )}
              </div>

              <TerminalLogs logs={logs} />

              {/* Protocol Steps */}
              <div className="slab p-8 space-y-8">
                <h3 className="font-black uppercase tracking-widest text-xs border-b-4 border-black pb-4">Protocolo de Operación</h3>
                <div className="space-y-6">
                  {[
                    { n: '01', t: 'Cotización Nominal', d: 'Ingresa el monto bruto a enviar desde tu cuenta PayPal verificada.' },
                    { n: '02', t: 'Validación KYC', d: 'Carga los datos de destino para Pago Móvil o transferencia bancaria.' },
                    { n: '03', t: 'Facturación Final', d: 'Recibes invoice formal de PayPal para procesar el envío seguro.' }
                  ].map((item) => (
                    <div key={item.n} className="flex gap-4 group">
                      <span className="mono font-black text-2xl opacity-10 group-hover:opacity-100 transition-opacity">{item.n}</span>
                      <div>
                        <h4 className="font-black text-xs uppercase">{item.t}</h4>
                        <p className="text-[10px] text-gray-500 font-bold uppercase leading-tight mt-1">{item.d}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>

          {/* BRUTALIST FOOTER */}
          <footer className="mt-32 pt-16 border-t-8 border-black animate-in fade-in duration-1000">
            <div className="flex flex-col md:flex-row justify-between gap-12">
              <div className="max-w-md">
                <h2 className="font-black italic text-2xl mb-6">PAYPAL360_TERMINAL</h2>
                <p className="mono text-[10px] font-bold text-gray-500 uppercase leading-relaxed">
                  Este sistema opera bajo estrictas normativas de cumplimiento AML/KYC. No se permiten pagos de terceros. Todas las transacciones son finales una vez procesadas por el nodo bancario. P360 no almacena credenciales de acceso.
                </p>
              </div>
              <div className="flex flex-wrap gap-12">
                <div className="space-y-4">
                  <span className="mono text-[10px] font-black bg-black text-white px-2 py-1 uppercase">Soporte_Directo</span>
                  <ul className="mono text-[10px] font-bold uppercase space-y-2">
                    <li className="hover:text-[#00ff66] cursor-pointer">Telegram: @P360_Support</li>
                    <li className="hover:text-[#00ff66] cursor-pointer">Email: ops@p360ve.com</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <span className="mono text-[10px] font-black bg-black text-white px-2 py-1 uppercase">Legales</span>
                  <ul className="mono text-[10px] font-bold uppercase space-y-2">
                    <li className="hover:underline cursor-pointer">Términos y Cond.</li>
                    <li className="hover:underline cursor-pointer">Privacidad / AML</li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="mt-16 pb-12 flex justify-between items-center border-t-2 border-black border-dashed pt-8">
              <span className="mono text-[10px] font-black uppercase">©{new Date().getFullYear()} P360 TERMINAL. NO_RIGHTS_RESERVED_FOR_BOTS.</span>
              <div className="flex gap-2">
                <div className="w-4 h-4 bg-black"></div>
                <div className="w-4 h-4 bg-black opacity-50"></div>
                <div className="w-4 h-4 bg-black opacity-20"></div>
              </div>
            </div>
          </footer>
        </div>
      </main>
    </div>
  );
};

export default App;
