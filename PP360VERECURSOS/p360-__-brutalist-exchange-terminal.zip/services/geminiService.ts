
import { GoogleGenAI, Type } from "@google/genai";
import { MarketInsight } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getMarketInsight = async (currentRate: number): Promise<MarketInsight> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Provide a short, brutalist-style market insight for the USD/VES exchange rate (currently ${currentRate}). 
      Keep it professional but punchy.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            headline: { type: Type.STRING, description: "A punchy headline about the market." },
            sentiment: { type: Type.STRING, enum: ["positive", "neutral", "negative"] },
            prediction: { type: Type.STRING, description: "A short prediction or warning." },
          },
          required: ["headline", "sentiment", "prediction"],
        },
      },
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini failed to generate insight:", error);
    return {
      headline: "DATA_LINK_STABLE",
      sentiment: "neutral",
      prediction: "Market volatility remains within expected parameters. Monitor volume."
    };
  }
};
