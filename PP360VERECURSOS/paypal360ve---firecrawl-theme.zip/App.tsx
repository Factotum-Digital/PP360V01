import React, { useState, useEffect } from 'react';
import { 
  ArrowDown, 
  ChevronRight, 
  ShieldCheck, 
  Clock, 
  Info
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { Navbar } from './Navbar';
import { Sidebar } from './Sidebar';

// --- Constantes y Configuración ---
const APP_NAME = "Paypal360VE";
const CURRENT_RATE = 400; // Tasa solicitada por el usuario
const COMISSION_RATE = 0.05; // 5% de comisión estándar

const VENEZUELAN_BANKS = [
  { code: '0102', name: 'Banco de Venezuela' },
  { code: '0105', name: 'Mercantil Banco' },
  { code: '0108', name: 'Provincial' },
  { code: '0134', name: 'Banesco' },
  { code: '0172', name: 'Bancamiga' },
  { code: '0175', name: 'Banplus' },
  { code: '0114', name: 'Bancaribe' },
  { code: '0163', name: 'Tesoro' }
];

const RATE_HISTORY = [
  { date: '18 Dic', rate: 392 },
  { date: '19 Dic', rate: 395 },
  { date: '20 Dic', rate: 398 },
  { date: '21 Dic', rate: 400 },
  { date: '22 Dic', rate: 400 },
  { date: 'Hoy', rate: 400 },
];

const PaymentMethod = {
  PAGO_MOVIL: 'PAGO_MOVIL',
  TRANSFERENCIA: 'TRANSFERENCIA'
};

// --- Componentes Internos Estilizados ---

const RateChart = () => (
  <div className="bg-surface border border-white/5 p-6 rounded-2xl h-full flex flex-col justify-between relative overflow-hidden group">
    {/* Subtle glow effect in background */}
    <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-3xl -z-10 group-hover:bg-primary/10 transition-colors duration-500"></div>

    <div>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="font-mono text-xs uppercase tracking-widest text-textMuted mb-2">Tasa de Hoy</h3>
          <div className="text-3xl font-bold font-mono text-white tracking-tight">
            {CURRENT_RATE.toFixed(2)} <span className="text-sm text-textMuted font-sans">VEF/USD</span>
          </div>
        </div>
        <div className="px-3 py-1 bg-white/5 border border-white/10 font-mono text-[10px] rounded-md text-primary">
          PAYPAL → BS
        </div>
      </div>
    </div>
    
    <div className="h-48 w-full mt-2">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={RATE_HISTORY}>
          <defs>
            <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#FA5D19" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#FA5D19" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <XAxis 
            dataKey="date" 
            tick={{fontSize: 10, fontFamily: 'JetBrains Mono', fill: '#525252'}} 
            axisLine={false}
            tickLine={false}
            dy={10}
          />
          <YAxis hide domain={['dataMin - 5', 'dataMax + 5']} />
          <Tooltip 
            contentStyle={{ 
              borderRadius: '8px', 
              border: '1px solid #333', 
              fontSize: '12px',
              backgroundColor: '#1A1A1A',
              color: '#fff',
              boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.5)'
            }}
            itemStyle={{ color: '#FA5D19' }}
          />
          <Area 
            type="monotone" 
            dataKey="rate" 
            stroke="#FA5D19" 
            strokeWidth={2}
            fillOpacity={1} 
            fill="url(#colorRate)" 
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
    <p className="text-[10px] text-textMuted mt-4 font-mono uppercase opacity-50">
      Actualizado: Recién
    </p>
  </div>
);

// --- Componente Principal ---

export default function App() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    usdAmount: 50,
    vefAmount: 0,
    paymentMethod: PaymentMethod.PAGO_MOVIL,
    fullName: '',
    cedula: '',
    bank: '',
    phoneNumber: '',
    accountNumber: '',
    paypalEmail: ''
  });

  // Cálculo automático
  useEffect(() => {
    const netUsd = formData.usdAmount * (1 - COMISSION_RATE);
    const calculatedVef = netUsd * CURRENT_RATE;
    setFormData(prev => ({ ...prev, vefAmount: Math.floor(calculatedVef) }));
  }, [formData.usdAmount]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const nextStep = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
  };

  const completeOrder = () => {
    setStep(3);
  };

  return (
    <div className="min-h-screen bg-background text-textMain font-sans selection:bg-primary/30 selection:text-white">
      <Navbar />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-4 md:p-8 lg:p-12 overflow-y-auto min-h-[calc(100vh-64px)]">
          <div className="max-w-6xl mx-auto">
            
            {/* Firecrawl-style Hero */}
            <header className="mb-12 text-center md:text-left relative">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-medium mb-6 animate-fade-in-up">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                  </span>
                  Sistema operativo para cambio PayPal → Bs
                </div>
                <h1 className="text-4xl md:text-6xl font-semibold tracking-tight text-white mb-4">
                  Cambio <span className="text-textMuted">Inteligente</span>
                </h1>
                <p className="text-textMuted text-lg max-w-2xl font-light">
                    La forma más segura y rápida de convertir tu saldo PayPal a Bolívares.
                    Sin intermediarios riesgosos, directo a tu cuenta.
                </p>
            </header>

            <div className="grid lg:grid-cols-3 gap-6">
              
              {/* Columna Izquierda (2/3): El Formulario */}
              <div className="lg:col-span-2">
                {step === 3 ? (
                  <div className="bg-surface border border-white/5 text-white p-12 rounded-2xl shadow-2xl text-center flex flex-col items-center animate-in fade-in slide-in-from-bottom-4 duration-700 h-full justify-center">
                    <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mb-6 shadow-[0_0_30px_-10px_#FA5D19]">
                      <ShieldCheck className="text-primary w-10 h-10" />
                    </div>
                    <h2 className="text-3xl font-bold mb-4">¡Orden Procesada!</h2>
                    <p className="text-textMuted text-sm mb-8 max-w-sm">
                      Hemos generado una factura PayPal por <b className="text-white">${formData.usdAmount}</b> y la enviamos a <b className="text-white">{formData.paypalEmail}</b>. 
                    </p>
                    <div className="bg-white/5 w-full max-w-md rounded-xl p-6 font-mono text-left mb-8 border border-white/5">
                       <div className="flex justify-between text-xs mb-3 pb-3 border-b border-white/5">
                          <span className="text-textMuted">RECIBES EN BANCO:</span>
                          <span className="text-green-400 font-bold">Bs. {formData.vefAmount.toLocaleString('es-VE')}</span>
                       </div>
                       <div className="flex justify-between text-xs">
                          <span className="text-textMuted">ID TRANSACCIÓN:</span>
                          <span className="text-white">#P360-{Math.floor(Math.random() * 999999)}</span>
                       </div>
                    </div>
                    <button 
                      onClick={() => setStep(1)}
                      className="bg-white hover:bg-gray-200 text-black px-8 py-3 rounded-lg text-sm font-bold transition-all"
                    >
                      Realizar otro cambio
                    </button>
                  </div>
                ) : (
                  <div className="bg-surface border border-white/5 p-8 rounded-2xl shadow-lg h-full">
                    {/* Stepper */}
                    <div className="flex items-center gap-3 mb-10">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${step === 1 ? 'bg-primary text-white shadow-[0_0_15px_-5px_#FA5D19]' : 'bg-green-500/20 text-green-500'}`}>
                        {step === 1 ? '1' : '✓'}
                      </div>
                      <div className="h-px w-8 bg-white/10" />
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${step === 2 ? 'bg-primary text-white shadow-[0_0_15px_-5px_#FA5D19]' : 'bg-white/5 text-textMuted'}`}>
                        2
                      </div>
                      <span className="ml-2 font-mono text-[10px] uppercase tracking-widest text-textMuted">
                        {step === 1 ? 'Calculadora' : 'Datos de Recepción'}
                      </span>
                    </div>

                    {step === 1 ? (
                      <form onSubmit={nextStep} className="space-y-8">
                        <div>
                          <label className="font-mono text-[10px] uppercase tracking-widest text-textMuted block mb-3">Tú envías (USD PayPal)</label>
                          <div className="relative group">
                            <div className="absolute left-5 top-1/2 -translate-y-1/2 font-mono text-xl text-textMuted group-focus-within:text-primary transition-colors">$</div>
                            <input 
                              type="number"
                              value={formData.usdAmount}
                              onChange={(e) => setFormData({...formData, usdAmount: Number(e.target.value)})}
                              min="5"
                              className="w-full bg-[#1A1A1A] border border-white/10 p-5 pl-12 text-3xl font-mono text-white focus:border-primary focus:ring-1 focus:ring-primary/50 rounded-xl transition-all outline-none placeholder:text-white/20"
                            />
                          </div>
                        </div>

                        <div className="flex justify-center -my-5 relative z-10">
                          <div className="bg-[#262626] border border-white/10 rounded-full p-2 shadow-lg hover:border-primary/50 transition-colors">
                            <ArrowDown size={16} className="text-textMuted" />
                          </div>
                        </div>

                        <div>
                          <label className="font-mono text-[10px] uppercase tracking-widest text-textMuted block mb-3">Tú recibes (Bolívares)</label>
                          <div className="relative">
                            <div className="absolute left-5 top-1/2 -translate-y-1/2 font-mono text-xl text-textMuted italic">Bs.</div>
                            <input 
                              type="text"
                              value={formData.vefAmount.toLocaleString('es-VE')}
                              readOnly
                              className="w-full bg-[#1A1A1A]/50 border border-white/5 p-5 pl-14 text-3xl font-bold font-mono rounded-xl cursor-default text-white/90"
                            />
                          </div>
                          <div className="mt-4 flex items-center gap-2 text-[10px] text-textMuted font-mono bg-white/5 p-2 rounded w-fit">
                            <Info size={12} className="text-primary" />
                            <span>INCLUYE COMISIÓN 5% + TASA BS. {CURRENT_RATE}</span>
                          </div>
                        </div>

                        <button 
                          type="submit"
                          className="w-full bg-primary hover:bg-[#ff7a40] text-white py-5 rounded-xl font-bold uppercase tracking-widest text-xs flex justify-between px-8 items-center group transition-all shadow-[0_0_20px_-5px_rgba(250,93,25,0.4)]"
                        >
                          Continuar
                          <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
                        </button>
                      </form>
                    ) : (
                      <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
                        <div className="grid grid-cols-2 gap-4">
                          <button 
                            onClick={() => setFormData({...formData, paymentMethod: PaymentMethod.PAGO_MOVIL})}
                            className={`p-4 rounded-xl border text-xs font-bold transition-all ${formData.paymentMethod === PaymentMethod.PAGO_MOVIL ? 'border-primary bg-primary/10 text-primary' : 'border-white/10 bg-[#1A1A1A] text-textMuted hover:border-white/20'}`}
                          >
                            PAGO MÓVIL
                          </button>
                          <button 
                            onClick={() => setFormData({...formData, paymentMethod: PaymentMethod.TRANSFERENCIA})}
                            className={`p-4 rounded-xl border text-xs font-bold transition-all ${formData.paymentMethod === PaymentMethod.TRANSFERENCIA ? 'border-primary bg-primary/10 text-primary' : 'border-white/10 bg-[#1A1A1A] text-textMuted hover:border-white/20'}`}
                          >
                            TRANSFERENCIA
                          </button>
                        </div>

                        <div className="space-y-4">
                          <input 
                            name="fullName"
                            placeholder="Nombre completo del titular"
                            onChange={handleInputChange}
                            className="w-full p-4 bg-[#1A1A1A] border border-white/10 rounded-xl text-sm text-white focus:border-primary transition-all outline-none placeholder:text-white/20"
                          />
                          <div className="grid grid-cols-2 gap-4">
                            <input 
                              name="cedula"
                              placeholder="Cédula (V-123...)"
                              onChange={handleInputChange}
                              className="w-full p-4 bg-[#1A1A1A] border border-white/10 rounded-xl text-sm text-white focus:border-primary transition-all outline-none placeholder:text-white/20"
                            />
                            <select 
                              name="bank"
                              onChange={handleInputChange}
                              className="w-full p-4 bg-[#1A1A1A] border border-white/10 rounded-xl text-sm text-white focus:border-primary transition-all outline-none appearance-none"
                            >
                              <option value="">Seleccionar Banco</option>
                              {VENEZUELAN_BANKS.map(b => (
                                <option key={b.code} value={b.code}>{b.name}</option>
                              ))}
                            </select>
                          </div>
                          
                          {formData.paymentMethod === PaymentMethod.PAGO_MOVIL ? (
                            <input 
                              name="phoneNumber"
                              placeholder="Número de Teléfono (04...)"
                              onChange={handleInputChange}
                              className="w-full p-4 bg-[#1A1A1A] border border-white/10 rounded-xl text-sm text-white focus:border-primary transition-all outline-none placeholder:text-white/20"
                            />
                          ) : (
                            <input 
                              name="accountNumber"
                              placeholder="Número de Cuenta (20 dígitos)"
                              onChange={handleInputChange}
                              className="w-full p-4 bg-[#1A1A1A] border border-white/10 rounded-xl text-sm text-white focus:border-primary transition-all outline-none placeholder:text-white/20"
                            />
                          )}

                          <div className="mt-8 pt-8 border-t border-white/5">
                             <label className="font-mono text-[10px] uppercase text-textMuted mb-2 block">Correo PayPal (Recepción de factura)</label>
                             <input 
                                name="paypalEmail"
                                type="email"
                                placeholder="tu-email@gmail.com"
                                onChange={handleInputChange}
                                className="w-full p-4 bg-primary/5 border border-primary/20 rounded-xl text-sm text-white focus:border-primary transition-all outline-none font-medium placeholder:text-white/20"
                             />
                          </div>
                        </div>

                        <div className="flex gap-4 pt-4">
                          <button 
                            onClick={() => setStep(1)}
                            className="w-1/3 py-4 border border-white/10 rounded-xl text-xs font-bold uppercase hover:bg-white/5 text-white transition-all"
                          >
                            Atrás
                          </button>
                          <button 
                            onClick={completeOrder}
                            disabled={!formData.paypalEmail || !formData.fullName}
                            className="w-2/3 bg-primary hover:bg-[#ff7a40] text-white py-4 rounded-xl font-bold uppercase tracking-widest text-xs shadow-[0_0_20px_-5px_rgba(250,93,25,0.4)] transition-all disabled:opacity-50 disabled:shadow-none"
                          >
                            Confirmar
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Columna Derecha (1/3): Información y Gráfico */}
              <div className="flex flex-col gap-6">
                <RateChart />
                
                <div className="bg-surface border border-white/5 p-8 rounded-2xl">
                  <h3 className="font-bold text-sm mb-6 flex items-center gap-2 text-white">
                    <Clock size={16} className="text-primary" />
                    Cómo funciona
                  </h3>
                  <div className="space-y-6">
                    {[
                      { step: '01', title: 'Calcula', desc: 'Indica cuánto deseas vender en el formulario.' },
                      { step: '02', title: 'Datos', desc: 'Ingresa tu Pago Móvil o cuenta bancaria.' },
                      { step: '03', title: 'Factura', desc: 'Paga la factura PayPal que llegará a tu correo.' },
                      { step: '04', title: 'Recibe', desc: 'El dinero cae en tu cuenta en minutos.' },
                    ].map((item, i) => (
                      <div key={i} className="flex gap-4">
                        <span className="font-mono text-[10px] text-primary/50 font-bold mt-1">{item.step}</span>
                        <div>
                          <h4 className="text-xs font-bold uppercase tracking-wider mb-1 text-white">{item.title}</h4>
                          <p className="text-[11px] text-textMuted leading-relaxed">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gradient-to-br from-[#1A1A1A] to-black border border-white/5 p-6 rounded-2xl flex items-center justify-between shadow-lg">
                  <div className="flex items-center gap-3">
                    <ShieldCheck className="text-green-500" size={20} />
                    <div className="text-[10px] font-mono leading-tight text-textMuted">
                      PROTECCIÓN AL <br/><span className="text-white">VENDEDOR 100%</span>
                    </div>
                  </div>
                  <div className="text-[10px] text-textMuted/50 italic border border-white/10 px-2 py-1 rounded">
                    SSL ENCRYPTED
                  </div>
                </div>
              </div>
            </div>

            <footer className="mt-24 border-t border-white/5 pt-10 pb-20">
              <div className="flex flex-col md:flex-row justify-between gap-10">
                <div className="max-w-xs">
                  <div className="font-bold tracking-tight text-sm mb-4 text-white">Paypal360<span className="text-primary">VE</span></div>
                  <p className="text-[10px] leading-loose uppercase tracking-widest text-textMuted/60">
                    Operamos bajo estrictas normas de seguridad. No se aceptan pagos de terceros.
                  </p>
                </div>
                <div className="text-[10px] font-mono space-y-2 text-textMuted">
                  <div className="text-white font-bold mb-2">CONTACTO</div>
                  <div className="hover:text-primary cursor-pointer transition-colors">SOPORTE@PAYPAL360VE.COM</div>
                  <div className="hover:text-primary cursor-pointer transition-colors">TELEGRAM: @PAYPAL360VE</div>
                </div>
              </div>
            </footer>
          </div>
        </main>
      </div>
    </div>
  );
}