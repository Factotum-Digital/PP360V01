import React from 'react';

export const Sidebar = () => (
  <aside className="w-64 border-r border-white/5 bg-[#0B0B0B] hidden lg:block h-[calc(100vh-64px)] overflow-y-auto sticky top-16">
    <div className="p-6">
      <p className="font-mono text-[10px] uppercase tracking-widest text-textMuted/50 mb-4">Operaciones</p>
      <div className="space-y-2">
        <div className="group flex justify-between items-center px-4 py-3 text-sm bg-primary/10 border border-primary/20 text-primary rounded-lg cursor-pointer transition-all">
          <span className="font-medium">Nueva Venta</span>
          <span className="font-mono text-[10px] opacity-70">01</span>
        </div>
        <div className="group flex justify-between items-center px-4 py-3 text-sm text-textMuted hover:text-white hover:bg-white/5 rounded-lg cursor-pointer transition-all border border-transparent">
          <span>Historial</span>
          <span className="font-mono text-[10px] opacity-50 group-hover:opacity-100">02</span>
        </div>
      </div>

      <div className="mt-12">
        <p className="font-mono text-[10px] uppercase tracking-widest text-textMuted/50 mb-4">Estado del Sistema</p>
        <div className="p-4 border border-white/5 bg-[#141414] rounded-xl text-xs text-textMuted leading-relaxed">
          <div className="flex items-center gap-2 mb-3 text-green-400 font-bold tracking-wide">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            SISTEMA ONLINE
          </div>
          <div className="space-y-1">
             <strong className="block text-white">Atención Inmediata</strong>
             <p className="opacity-70">Pagos en &lt; 15 mins.</p>
          </div>
        </div>
      </div>
    </div>
  </aside>
);