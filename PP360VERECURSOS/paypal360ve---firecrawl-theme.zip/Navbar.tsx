import React from 'react';
import { Menu } from 'lucide-react';

export const Navbar = () => (
  <nav className="h-16 border-b border-white/5 bg-[#0B0B0B]/80 backdrop-blur-md sticky top-0 z-50 px-6 flex items-center justify-between">
    <div className="flex items-center gap-3">
      <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center shadow-[0_0_15px_-3px_#FA5D19]">
        <span className="text-white font-bold text-xs">P3</span>
      </div>
      <span className="font-bold tracking-tight text-xl text-white">
        Paypal360<span className="text-primary">VE</span>
      </span>
    </div>
    
    <div className="hidden md:flex items-center gap-8 text-sm font-medium text-textMuted">
      <a href="#" className="hover:text-white transition-colors duration-200">Vender</a>
      <a href="#" className="hover:text-white transition-colors duration-200">Tasas</a>
      <a href="#" className="hover:text-white transition-colors duration-200">Ayuda</a>
    </div>

    <div className="flex items-center gap-4">
      <button className="hidden md:block bg-primary hover:bg-[#ff7a40] text-white px-5 py-2 rounded-full text-sm font-semibold transition-all shadow-[0_0_10px_-4px_#FA5D19]">
        Conectar Wallet
      </button>
      <button className="md:hidden text-textMuted hover:text-white">
        <Menu size={20} />
      </button>
    </div>
  </nav>
);