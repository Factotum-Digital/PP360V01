
import { GoogleGenAI } from "@google/genai";

export const getMarketIntelligence = async (sendMethod: string, receiveMethod: string, amount: number) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analiza una operación de cambio de ${amount} desde ${sendMethod} hacia ${receiveMethod} en el contexto del mercado venezolano actual. Proporciona un consejo breve (max 50 palabras) sobre seguridad o conveniencia. Sé directo y usa un tono profesional de analista financiero.`,
      config: {
        temperature: 0.7,
        maxOutputTokens: 150
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Kernel: Intelligence engine offline. Proceeding with standard security protocols.";
  }
};
