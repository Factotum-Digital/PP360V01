
import { PaymentMethod, ExchangeRateMap } from './types';

export const PAYMENT_METHODS: Record<string, PaymentMethod> = {
  paypal: {
    id: 'paypal',
    name: 'PayPal',
    currency: 'USD',
    symbol: '$',
    minSend: 10,
    maxSend: 5000,
    minReceive: 10,
    maxReceive: 5000,
    commission: 0.05,
    fields: ['email']
  },
  zelle: {
    id: 'zelle',
    name: 'Zelle',
    currency: 'USD',
    symbol: '$',
    minSend: 20,
    maxSend: 9000,
    minReceive: 10,
    maxReceive: 9000,
    commission: 0.02,
    fields: ['email_or_phone']
  },
  wise_usd: {
    id: 'wise_usd',
    name: 'Wise USD',
    currency: 'USD',
    symbol: '$',
    minSend: 10,
    maxSend: 8000,
    minReceive: 10,
    maxReceive: 8000,
    commission: 0.015,
    fields: ['email']
  },
  usdt: {
    id: 'usdt',
    name: 'USDT (Tether)',
    currency: 'USDT',
    symbol: '₮',
    minSend: 10,
    maxSend: 50000,
    minReceive: 10,
    maxReceive: 50000,
    commission: 0.01,
    fields: ['crypto_address', 'network']
  },
  pago_movil: {
    id: 'pago_movil',
    name: 'Pago Móvil',
    currency: 'VES',
    symbol: 'Bs',
    minSend: 500,
    maxSend: 500000,
    minReceive: 100,
    maxReceive: 500000,
    commission: 0.005,
    fields: ['phone', 'cedula', 'bank']
  },
  banco_ves: {
    id: 'banco_ves',
    name: 'Banco VES',
    currency: 'VES',
    symbol: 'Bs',
    minSend: 1000,
    maxSend: 1000000,
    minReceive: 1000,
    maxReceive: 1000000,
    commission: 0.005,
    fields: ['account_number', 'cedula', 'bank']
  }
};

export const EXCHANGE_RATES: ExchangeRateMap = {
  'paypal_pago_movil': 45.20,
  'zelle_pago_movil': 47.80,
  'wise_usd_pago_movil': 48.50,
  'usdt_pago_movil': 49.30,
  'pago_movil_paypal': 0.021,
  'pago_movil_zelle': 0.02,
  'pago_movil_usdt': 0.019,
  'banco_ves_pago_movil': 1.0,
  'pago_movil_banco_ves': 1.0
};
