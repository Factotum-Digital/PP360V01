
import React from 'react';

const Sidebar: React.FC = () => {
  return (
    <aside className="w-20 md:w-24 border-r-4 border-black bg-white hidden sm:flex flex-col items-center py-10 gap-12 z-20 sticky top-0 h-screen">
      <div className="bg-black text-white w-12 h-12 flex items-center justify-center font-black text-2xl border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,0.3)]">P</div>
      <nav className="flex flex-col gap-8">
        <button onClick={() => window.location.reload()} className="w-8 h-8 bg-black hover:bg-action-green transition-colors" title="Reload System"></button>
        <div className="w-8 h-8 border-4 border-black"></div>
        <div className="w-8 h-8 border-4 border-black opacity-20"></div>
      </nav>
      <div className="mt-auto [writing-mode:vertical-rl] rotate-180 font-black text-[10px] uppercase tracking-[0.3em] opacity-30">
        SECURE TERMINAL V.6.0
      </div>
    </aside>
  );
};

export default Sidebar;
