
import React, { useState, useEffect } from 'react';

const RateChart: React.FC = () => {
  const [points, setPoints] = useState<string>("");
  const [fillPoints, setFillPoints] = useState<string>("");

  const generatePath = () => {
    let d = "M0,60 ";
    let lastY = 60;
    for (let i = 1; i <= 12; i++) {
      const x = i * 20;
      const variation = (Math.random() - 0.5) * 35;
      lastY = Math.max(10, Math.min(70, lastY + variation));
      d += `L${x},${lastY} `;
    }
    setPoints(d);
    setFillPoints(d + " V80 H0 Z");
  };

  useEffect(() => {
    generatePath();
    const interval = setInterval(generatePath, 8000);
    return () => clearInterval(interval);
  }, []);

  return (
    <svg viewBox="0 0 240 80" className="w-full h-32 stroke-[#00cc99] fill-none opacity-80">
      <defs>
        <linearGradient id="rateGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" style={{ stopColor: '#00cc99', stopOpacity: 0.4 }} />
          <stop offset="100%" style={{ stopColor: '#00cc99', stopOpacity: 0 }} />
        </linearGradient>
      </defs>
      <path 
        d={fillPoints} 
        fill="url(#rateGrad)" 
        stroke="none" 
        className="transition-all duration-1000"
      />
      <path 
        d={points} 
        strokeWidth="4" 
        strokeLinejoin="round" 
        strokeLinecap="round"
        className="transition-all duration-1000"
      />
    </svg>
  );
};

export default RateChart;
