
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { PAYMENT_METHODS, EXCHANGE_RATES } from './constants';
import { TransactionState, LogEntry, PaymentMethod } from './types';
import { getMarketIntelligence } from './geminiService';
import Sidebar from './components/Sidebar';
import TerminalLogs from './components/TerminalLogs';
import RateChart from './components/RateChart';
import { 
  ArrowRight, 
  ArrowUpDown, 
  CheckCircle, 
  AlertTriangle, 
  ShieldCheck, 
  Clock, 
  Zap,
  Check,
  ChevronRight,
  Info
} from 'lucide-react';

const App: React.FC = () => {
  const [state, setState] = useState<TransactionState>({
    currentStep: 1,
    selectedSendId: null,
    selectedReceiveId: null,
    amount: 100,
    outputAmount: 0,
    rate: 0,
    commission: 0,
    formData: {}
  });

  const [logs, setLogs] = useState<LogEntry[]>([
    { timestamp: new Date().toLocaleTimeString(), message: "BOOTING_P360_KERNEL... DONE" },
    { timestamp: new Date().toLocaleTimeString(), message: "CONNECTING_API_SALDOAR... OK" },
    { timestamp: new Date().toLocaleTimeString(), message: "ESTABLISHING_SECURE_TUNNEL... ENCRYPTED" }
  ]);

  const [aiInsight, setAiInsight] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [operationId, setOperationId] = useState("");

  const addLog = (message: string) => {
    setLogs(prev => [
      { timestamp: new Date().toLocaleTimeString(), message },
      ...prev.slice(0, 49)
    ]);
  };

  // Corrección: Refactorización explícita para evitar problemas de cierre en React 19
  const handleMethodSelect = (type: 'send' | 'receive', methodId: string) => {
    setState(prev => {
      const nextState = { ...prev };
      if (type === 'send') {
        nextState.selectedSendId = methodId;
      } else {
        nextState.selectedReceiveId = methodId;
      }
      return nextState;
    });
    
    const methodName = PAYMENT_METHODS[methodId]?.name;
    addLog(`SET_${type.toUpperCase()}_CHANNEL: ${methodName}`);
  };

  // Update rates and calculation
  useEffect(() => {
    if (state.selectedSendId && state.selectedReceiveId) {
      const rateKey = `${state.selectedSendId}_${state.selectedReceiveId}`;
      const rate = EXCHANGE_RATES[rateKey] || (state.selectedSendId === state.selectedReceiveId ? 1 : 0);
      const sendMethod = PAYMENT_METHODS[state.selectedSendId];
      const receiveMethod = PAYMENT_METHODS[state.selectedReceiveId];
      
      const commission = receiveMethod.commission;
      const netAmount = state.amount * (1 - commission);
      const output = netAmount * (rate || 0);

      setState(prev => ({ 
        ...prev, 
        rate: rate || 0, 
        commission, 
        outputAmount: output 
      }));
    }
  }, [state.selectedSendId, state.selectedReceiveId, state.amount]);

  // AI Insight
  const triggerAiInsight = async () => {
    if (state.selectedSendId && state.selectedReceiveId) {
      setAiInsight("Analizando mercado...");
      const insight = await getMarketIntelligence(
        PAYMENT_METHODS[state.selectedSendId].name,
        PAYMENT_METHODS[state.selectedReceiveId].name,
        state.amount
      );
      setAiInsight(insight || "Sin datos adicionales.");
    }
  };

  const goToStep = (step: number) => {
    if (step === 2) {
      if (!state.selectedSendId || !state.selectedReceiveId) {
        addLog("ERROR: SELECCIÓN INCOMPLETA");
        return;
      }
      triggerAiInsight();
    }
    setState(prev => ({ ...prev, currentStep: step }));
    addLog(`NAVIGATED_TO_STEP_${step}`);
    window.scrollTo(0, 0);
  };

  const finalizeOrder = () => {
    setIsProcessing(true);
    addLog("PROCESSING_TRANSACTION...");
    addLog("ENCRYPTING_PAYMENT_DATA...");
    
    setTimeout(() => {
      const id = `P360-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
      setOperationId(id);
      setState(prev => ({ ...prev, currentStep: 4 }));
      setIsProcessing(false);
      addLog(`ORDER_COMMITTED: ${id}`);
    }, 2500);
  };

  const selectedSend = state.selectedSendId ? PAYMENT_METHODS[state.selectedSendId] : null;
  const selectedReceive = state.selectedReceiveId ? PAYMENT_METHODS[state.selectedReceiveId] : null;

  return (
    <div className="flex min-h-screen">
      {/* SIDEBAR */}
      <Sidebar />

      {/* MAIN CONTENT */}
      <main className="flex-1 p-6 md:p-12 lg:p-20">
        <div className="max-w-6xl mx-auto">
          
          <header className="mb-16">
            <div className="flex items-center gap-4 mb-4">
              <span className="mono text-[10px] bg-black text-white px-2 py-1">AUTH: OK</span>
              <span className="mono text-[10px] text-gray-400 uppercase">SERVER: CARACAS-NODE-01</span>
              <span className="mono text-[10px] bg-action-green text-black px-2 py-1 font-bold">OPERACIONAL</span>
            </div>
            <h1 className="text-6xl md:text-8xl font-black uppercase tracking-tighter leading-none">
              P360 <br /><span className="text-transparent" style={{ WebkitTextStroke: '2px black' }}>TERMINAL</span>
            </h1>
            <p className="mono text-sm mt-4 max-w-xl text-gray-500 font-bold uppercase">
              Operaciones de cambio de alta liquidez. Seguro. Instantáneo. Brutal.
            </p>
          </header>

          <div className="grid lg:grid-cols-12 gap-12">
            
            {/* LEFT: FORM MONOLITH */}
            <div className="lg:col-span-7 xl:col-span-8 space-y-12">
              
              <div className="slab p-6 md:p-10 relative overflow-hidden min-h-[650px] flex flex-col">
                {/* Step Indicators */}
                <div className="absolute top-0 right-0 flex border-l-4 border-b-4 border-black mono text-[10px] font-black">
                  {[1, 2, 3].map(s => (
                    <div 
                      key={s} 
                      className={`px-4 py-2 border-l-4 border-black transition-colors ${state.currentStep === s ? 'bg-black text-white' : 'bg-white text-black opacity-30'}`}
                    >
                      STEP_0{s}
                    </div>
                  ))}
                </div>

                {/* STEP 1: METHOD SELECTION */}
                {state.currentStep === 1 && (
                  <div className="space-y-10 animate-reveal mt-6">
                    <h3 className="mono text-2xl font-black uppercase underline decoration-4">Selección de Canal</h3>
                    
                    <div className="space-y-4">
                      <label className="mono text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                        <span className="w-3 h-3 bg-black"></span> TÚ ENVÍAS (ORIGEN)
                      </label>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {Object.values(PAYMENT_METHODS).map(m => (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => handleMethodSelect('send', m.id)}
                            className={`p-4 border-4 border-black transition-all mono text-left relative group ${state.selectedSendId === m.id ? 'bg-black text-white' : 'bg-white hover:bg-gray-100'}`}
                          >
                            <div className="font-black uppercase">{m.name}</div>
                            <div className={`text-[10px] ${state.selectedSendId === m.id ? 'text-gray-400' : 'text-gray-500'}`}>{m.currency}</div>
                            {state.selectedSendId === m.id && (
                              <Check className="absolute top-2 right-2 text-action-green" size={16} strokeWidth={4} />
                            )}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="mono text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                        <span className="w-3 h-3 bg-action-green"></span> TÚ RECIBES (DESTINO)
                      </label>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {Object.values(PAYMENT_METHODS).map(m => (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => handleMethodSelect('receive', m.id)}
                            className={`p-4 border-4 border-black transition-all mono text-left relative group ${state.selectedReceiveId === m.id ? 'bg-action-green text-black' : 'bg-white hover:bg-gray-100'}`}
                          >
                            <div className="font-black uppercase">{m.name}</div>
                            <div className="text-[10px] opacity-60">{m.currency}</div>
                            {state.selectedReceiveId === m.id && (
                              <Check className="absolute top-2 right-2 text-black" size={16} strokeWidth={4} />
                            )}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button 
                      type="button"
                      disabled={!state.selectedSendId || !state.selectedReceiveId}
                      onClick={() => goToStep(2)}
                      className="w-full mt-auto bg-black text-white p-8 text-xl font-black uppercase flex justify-between items-center slab-dark btn-press disabled:opacity-20 disabled:grayscale transition-all group"
                    >
                      <span>Cotizar Operación</span>
                      <ArrowRight className="group-hover:translate-x-2 transition-transform" strokeWidth={4} />
                    </button>
                  </div>
                )}

                {/* STEP 2: CALCULATOR */}
                {state.currentStep === 2 && selectedSend && selectedReceive && (
                  <div className="space-y-10 animate-reveal mt-6">
                    <h3 className="mono text-2xl font-black uppercase underline decoration-4">Cotización Real</h3>
                    
                    <div className="space-y-4">
                      <label className="mono text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                        TÚ ENVÍAS ({selectedSend.currency})
                      </label>
                      <div className="relative">
                        <span className="absolute left-6 top-1/2 -translate-y-1/2 font-black text-4xl opacity-20">{selectedSend.symbol}</span>
                        <input 
                          type="number"
                          value={state.amount}
                          onChange={(e) => setState(prev => ({ ...prev, amount: Number(e.target.value) }))}
                          className="w-full bg-gray-100 border-b-8 border-black p-8 pl-16 text-5xl font-black mono focus:bg-white transition-all outline-none"
                        />
                      </div>
                      <div className="mono text-[10px] text-gray-500 font-bold uppercase">
                        LIMITS: MIN {selectedSend.symbol}{selectedSend.minSend} | MAX {selectedSend.symbol}{selectedSend.maxSend.toLocaleString()}
                      </div>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="h-1 flex-1 bg-black"></div>
                      <div className="w-12 h-12 border-4 border-black flex items-center justify-center bg-white">
                        <ArrowUpDown strokeWidth={4} />
                      </div>
                      <div className="h-1 flex-1 bg-black"></div>
                    </div>

                    <div className="space-y-4">
                      <label className="mono text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                        TÚ RECIBES ({selectedReceive.currency})
                      </label>
                      <div className="relative">
                        <span className="absolute left-6 top-1/2 -translate-y-1/2 font-black text-4xl opacity-20">{selectedReceive.symbol}</span>
                        <input 
                          readOnly
                          value={state.outputAmount.toLocaleString('es-VE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          className="w-full bg-black text-white p-8 pl-24 text-5xl font-black mono cursor-not-allowed outline-none"
                        />
                      </div>
                      <div className="flex justify-between mono text-[10px] font-black text-gray-500 uppercase">
                        <span>TASA: 1 {selectedSend.currency} = {state.rate.toFixed(4)} {selectedReceive.currency}</span>
                        <span>COMISIÓN: {(state.commission * 100).toFixed(1)}%</span>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-6 border-l-8 border-blue-500 flex gap-4 items-start">
                      <Zap className="text-blue-500 shrink-0" size={24} strokeWidth={3} />
                      <div>
                        <div className="mono text-[10px] font-black uppercase text-blue-500 mb-1">AI_MARKET_INSIGHT</div>
                        <p className="mono text-[11px] font-bold uppercase leading-tight">{aiInsight}</p>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <button onClick={() => goToStep(1)} className="w-1/3 border-4 border-black p-6 font-black uppercase mono hover:bg-gray-100 btn-press">Volver</button>
                      <button onClick={() => goToStep(3)} className="flex-1 bg-black text-white p-6 text-xl font-black uppercase slab-dark btn-press">Continuar</button>
                    </div>
                  </div>
                )}

                {/* STEP 3: DETAILS */}
                {state.currentStep === 3 && selectedSend && selectedReceive && (
                  <div className="space-y-8 animate-reveal mt-6">
                    <h3 className="mono text-2xl font-black uppercase underline decoration-4">Datos de Liquidación</h3>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                      {[...selectedSend.fields, ...selectedReceive.fields].map((field, idx) => (
                        <div key={idx} className="space-y-2">
                          <label className="mono text-[10px] font-black uppercase">{field.replace('_', ' ')} *</label>
                          <input 
                            type="text"
                            placeholder="REQUERIDO"
                            onChange={(e) => setState(prev => ({ ...prev, formData: { ...prev.formData, [field]: e.target.value } }))}
                            className="w-full border-4 border-black p-4 font-bold mono outline-none"
                          />
                        </div>
                      ))}
                    </div>

                    <div className="bg-yellow-100 p-4 border-l-8 border-black flex gap-4">
                      <AlertTriangle className="shrink-0" size={24} />
                      <p className="mono text-[10px] font-bold leading-tight uppercase">
                        Solo aceptamos pagos de cuentas verificadas y a nombre del titular de la cuenta de destino. El incumplimiento causará retrasos.
                      </p>
                    </div>

                    <div className="flex gap-4">
                      <button onClick={() => goToStep(2)} className="w-1/3 border-4 border-black p-6 font-black uppercase mono hover:bg-gray-100 btn-press">Volver</button>
                      <button 
                        onClick={finalizeOrder}
                        disabled={isProcessing}
                        className="flex-1 bg-black text-white p-6 text-xl font-black uppercase slab-dark btn-press relative flex justify-center items-center"
                      >
                        {isProcessing ? 'Procesando Kernel...' : 'Generar Orden'}
                      </button>
                    </div>
                  </div>
                )}

                {/* SUCCESS */}
                {state.currentStep === 4 && (
                  <div className="flex flex-col items-center justify-center py-16 text-center animate-reveal">
                    <div className="w-24 h-24 bg-action-green border-4 border-black flex items-center justify-center mb-8">
                      <CheckCircle size={48} strokeWidth={3} />
                    </div>
                    <h3 className="text-5xl font-black uppercase mb-4">Orden Transmitida</h3>
                    <div className="mono space-y-4 max-w-md">
                      <p className="text-sm font-bold uppercase">ID Operación: <span className="bg-black text-white px-2 py-1">{operationId}</span></p>
                      <div className="bg-gray-100 p-6 border-4 border-black text-left space-y-2">
                        <div className="flex justify-between text-xs"><span>Envías:</span> <span className="font-black">{selectedSend?.symbol}{state.amount} {selectedSend?.currency}</span></div>
                        <div className="flex justify-between text-xs text-action-green"><span>Recibes:</span> <span className="font-black">{selectedReceive?.symbol}{state.outputAmount.toLocaleString()} {selectedReceive?.currency}</span></div>
                        <div className="flex justify-between text-xs opacity-40"><span>Método:</span> <span className="font-black uppercase">{selectedSend?.name} → {selectedReceive?.name}</span></div>
                      </div>
                      <p className="text-[10px] text-gray-400 font-bold uppercase">Hemos enviado las instrucciones de pago a tu terminal registrado. Tiempo estimado de liquidación: 15 min.</p>
                    </div>
                    <button 
                      onClick={() => window.location.reload()}
                      className="mt-12 border-4 border-black px-12 py-4 font-black mono uppercase hover:bg-black hover:text-white transition-all btn-press"
                    >
                      Nueva Operación
                    </button>
                  </div>
                )}
              </div>

              {/* INFO STRIP */}
              <div className="grid md:grid-cols-3 gap-6">
                <div className="slab p-6 bg-yellow-300">
                  <ShieldCheck className="mb-2" size={20} strokeWidth={3} />
                  <div className="mono text-[10px] font-black mb-1 uppercase tracking-wider">Kernel_Security</div>
                  <p className="text-[9px] font-bold leading-tight uppercase">Encriptación AES-256 en cada fragmento de dato.</p>
                </div>
                <div className="slab p-6">
                  <Clock className="mb-2" size={20} strokeWidth={3} />
                  <div className="mono text-[10px] font-black mb-1 uppercase tracking-wider">Fast_Track</div>
                  <p className="text-[9px] font-bold leading-tight uppercase">Liquidación promedio de 15 minutos hoy.</p>
                </div>
                <div className="slab p-6 bg-black text-white">
                  <Zap className="mb-2 text-action-green" size={20} strokeWidth={3} />
                  <div className="mono text-[10px] font-black mb-1 uppercase tracking-wider text-action-green">Deep_Liquidity</div>
                  <p className="text-[9px] font-bold leading-tight uppercase">Operando con fondos inmediatos en 12 canales.</p>
                </div>
              </div>
            </div>

            {/* RIGHT: ANALYTICS & LOGS */}
            <div className="lg:col-span-5 xl:col-span-4 space-y-8">
              
              {/* CHART */}
              <div className="slab p-8 bg-black text-white overflow-hidden relative min-h-[250px]">
                <div className="flex justify-between items-start mb-8">
                   <h3 className="mono text-[10px] font-black tracking-widest uppercase">HISTÓRICO_TASA_GLOBAL</h3>
                   <span className="bg-action-green text-black px-2 py-1 mono text-[10px] font-black">+4.2%</span>
                </div>
                <RateChart />
                <div className="mt-4 flex justify-between mono text-[10px] text-gray-500 font-black">
                  <span>08:00</span>
                  <span>12:00</span>
                  <span>16:00</span>
                  <span>AHORA</span>
                </div>
              </div>

              {/* LIVE RATES TABLE */}
              <div className="slab p-6 space-y-6">
                <h3 className="font-black uppercase tracking-widest text-[11px] border-b-4 border-black pb-4 flex items-center gap-2">
                  <Zap size={14} /> Tasas del Mercado
                </h3>
                <div className="space-y-3">
                  {Object.entries(EXCHANGE_RATES).slice(0, 4).map(([key, val], idx) => {
                    const [from, to] = key.split('_');
                    return (
                      <div key={idx} className="flex justify-between items-center p-3 border-2 border-black hover:bg-gray-100 transition-colors cursor-default">
                        <span className="mono text-[11px] font-black uppercase">{from} / {to}</span>
                        <div className="flex gap-4 mono text-[11px] font-black">
                          <span className="text-action-green">↑{val.toFixed(2)}</span>
                          <span className="text-gray-300">↓{(val - 0.2).toFixed(2)}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* LOGS */}
              <TerminalLogs logs={logs} />

              {/* PROTOCOL */}
              <div className="slab p-8 space-y-8">
                <h3 className="font-black uppercase tracking-widest text-[11px] border-b-4 border-black pb-4">Protocolo de Operación</h3>
                <div className="space-y-6">
                  {[
                    { n: '01', t: 'Identificación', d: 'Validación de canales y límites operativos.' },
                    { n: '02', t: 'Verificación', d: 'Análisis de mercado y cotización en vivo.' },
                    { n: '03', t: 'Liquidación', d: 'Trasmisión segura de fondos via kernel P360.' }
                  ].map((step, idx) => (
                    <div key={idx} className="flex gap-4 group cursor-default">
                      <span className="mono font-black text-2xl opacity-10 group-hover:opacity-100 transition-opacity" aria-hidden="true">{step.n}</span>
                      <div>
                        <h4 className="font-black text-[10px] uppercase">{step.t}</h4>
                        <p className="text-[10px] text-gray-500 font-bold uppercase leading-tight mt-1">{step.d}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>

          {/* FOOTER */}
          <footer className="mt-32 pt-16 border-t-8 border-black">
            <div className="flex flex-col md:flex-row justify-between gap-12">
              <div className="max-w-md">
                <h2 className="font-black italic text-2xl mb-6">P360_NETWORK</h2>
                <p className="mono text-[10px] font-bold text-gray-500 uppercase leading-relaxed">
                  Terminal de alto rendimiento para el ecosistema financiero venezolano. Cumplimiento estricto de KYC/AML. Operado por ingenieros, diseñado para la eficiencia.
                </p>
              </div>
              <div className="flex flex-wrap gap-12">
                <div className="space-y-4">
                  <span className="mono text-[10px] font-black bg-black text-white px-2 py-1 uppercase">Soporte_Kernel</span>
                  <ul className="mono text-[10px] font-bold uppercase space-y-2 text-gray-600">
                    <li>Telegram: @P360_Kernel</li>
                    <li>Email: support@p360.network</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <span className="mono text-[10px] font-black bg-black text-white px-2 py-1 uppercase">Legal_Core</span>
                  <ul className="mono text-[10px] font-bold uppercase space-y-2 text-gray-600">
                    <li><a href="#" className="hover:underline">Terms of Protocol</a></li>
                    <li><a href="#" className="hover:underline">Privacy Layer</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="mt-16 pb-12 flex justify-between items-center border-t-2 border-black border-dashed pt-8">
              <span className="mono text-[9px] font-black uppercase">©2025 P360 Venezuela. Built on React 19 & Gemini API.</span>
              <div className="flex gap-2">
                <div className="w-4 h-4 bg-black"></div>
                <div className="w-4 h-4 bg-black opacity-50"></div>
                <div className="w-4 h-4 bg-black opacity-20"></div>
              </div>
            </div>
          </footer>
        </div>
      </main>
    </div>
  );
};

export default App;
