
import React from 'react';

interface SlabProps {
  children: React.ReactNode;
  className?: string;
  dark?: boolean;
  onClick?: () => void;
}

export const Slab: React.FC<SlabProps> = ({ children, className = '', dark = false, onClick }) => {
  const baseClasses = "border-4 border-black transition-all duration-200 cursor-pointer";
  const hoverClasses = onClick ? "hover:-translate-x-1 hover:-translate-y-1 hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] active:translate-x-1 active:translate-y-1 active:shadow-none" : "";
  const colorClasses = dark 
    ? "bg-black text-white shadow-[6px_6px_0px_0px_rgba(0,0,0,0.3)]" 
    : "bg-white text-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]";

  return (
    <div 
      onClick={onClick}
      className={`${baseClasses} ${colorClasses} ${hoverClasses} ${className}`}
    >
      {children}
    </div>
  );
};

export const Tag: React.FC<{ children: React.ReactNode; active?: boolean }> = ({ children, active }) => (
  <span className={`mono text-xs px-2 py-1 uppercase font-bold border-2 border-black ${active ? 'bg-black text-white' : 'bg-white text-black'}`}>
    {children}
  </span>
);
